# Handfont

Draw each letter, get a real `.ttf` font. Fully offline, no login, no internet permission.

## Build the APK (needs Flutter installed on a computer)

1. Make a fresh project, then copy these files into it:
   ```
   flutter create --org com.handfont --project-name glyphdraw handfont
   ```
   Copy `lib/`, `assets/` and `pubspec.yaml` from this folder into `handfont/` (replace existing).
2. Replace `handfont/android/app/src/main/kotlin/com/handfont/glyphdraw/MainActivity.kt`
   with `android_files/MainActivity.kt`.
3. Open `handfont/android/app/src/main/AndroidManifest.xml`:
   - paste `android_files/manifest_queries.xml` above `<application>`
   - set `android:label="Handfont"` on `<application>`
   - do NOT add an INTERNET permission
4. In `handfont/android/app/build.gradle(.kts)` set `minSdk = 29`.
5. Run:
   ```
   cd handfont
   flutter pub get
   dart run flutter_launcher_icons
   flutter build apk --release
   ```
   The APK is at `build/app/outputs/flutter-apk/app-release.apk`.

## How it works
- Drawing screen: 3 x 4 grid per page (A-L, M-X, ...), pen/eraser, thickness slider, undo/redo.
- Export: strokes become filled outlines in a real TrueType font (`lib/ttf.dart`).
- Compatibility check runs on every launch (`lib/compat.dart`): reads brand, Android version and
  whether a Theme Store exists. Result is "Likely compatible" or "Export only".
- Realme/Oppo/OnePlus: after export the app can open the Theme Store; applying a font there depends on
  your Realme UI version.

## Build with GitHub (no local setup)
Push this folder to a GitHub repo. Open the **Actions** tab, run **Build APK** (it also runs on every push),
then download `Handfont-apk` from the finished run and install `app-release.apk`.
