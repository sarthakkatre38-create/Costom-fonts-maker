import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:glyphdraw/ttf.dart';

int u16(Uint8List b, int o) => (b[o] << 8) | b[o + 1];
int u32(Uint8List b, int o) => (u16(b, o) << 16) | u16(b, o + 2);

Map<String, int> tables(Uint8List b) {
  final n = u16(b, 4);
  return {
    for (var i = 0; i < n; i++)
      String.fromCharCodes(b.sublist(12 + 16 * i, 16 + 16 * i)): u32(b, 12 + 16 * i + 8),
  };
}

void main() {
  final Map<String, List<List<List<double>>>> sample = {
    'A': [
      [
        [0.15, 0.78],
        [0.5, 0.12],
        [0.85, 0.78]
      ],
      [
        [0.28, 0.55],
        [0.72, 0.55]
      ],
    ],
    'o': [
      [
        for (var i = 0; i <= 40; i++)
          [0.5 + 0.3 * math.cos(i / 40 * 2 * math.pi), 0.5 + 0.3 * math.sin(i / 40 * 2 * math.pi)]
      ],
    ],
    '.': [
      [
        [0.5, 0.76]
      ],
    ],
  };

  test('builds a valid sfnt with 10 tables and correct checksum', () {
    final b = buildTtf(family: 'Test Font', glyphs: sample);
    expect(u32(b, 0), 0x00010000);
    expect(u16(b, 4), 10);
    var sum = 0;
    for (var i = 0; i + 3 < b.length; i += 4) {
      sum = (sum + u32(b, i)) & 0xFFFFFFFF;
    }
    expect(b.length % 4, 0);
    expect(sum, 0xB1B0AFBA);
  });

  test('glyph count = notdef + space + drawn characters', () {
    final b = buildTtf(family: 'Test Font', glyphs: sample);
    final t = tables(b);
    expect(u16(b, t['maxp']! + 4), 5);
    expect(u16(b, t['head']! + 18), 1000); // unitsPerEm
  });

  test('empty font does not crash', () {
    final b = buildTtf(family: '', glyphs: {});
    expect(u32(b, 0), 0x00010000);
    expect(u16(b, tables(b)['maxp']! + 4), 2);
  });

  test('huge scribble stays under the 65535 point limit', () {
    final rnd = math.Random(1);
    final strokes = <List<List<double>>>[
      for (var s = 0; s < 60; s++)
        [
          for (var i = 0; i < 400; i++) [rnd.nextDouble(), rnd.nextDouble()]
        ]
    ];
    final b = buildTtf(family: 'Big', glyphs: {'W': strokes});
    final t = tables(b);
    expect(u16(b, t['maxp']! + 6), lessThan(65535));
  });
}
