package com.handfont.glyphdraw

import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    // Theme / font stores used by Realme, Oppo and OnePlus phones
    private val themePkgs = listOf(
        "com.heytap.themestore", "com.oppo.themestore", "com.nearme.themestore",
        "com.coloros.themestore", "com.oplus.themestore", "com.heytap.theme"
    )

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "handfont/device")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "info" -> result.success(info())
                    "openThemeStore" -> result.success(openThemeStore())
                    "saveToDownloads" -> {
                        val path = call.argument<String>("path")
                        val name = call.argument<String>("name")
                        result.success(if (path != null && name != null) saveToDownloads(path, name) else null)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun installed(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) { false }

    private fun info(): Map<String, Any?> {
        val pkg = themePkgs.firstOrNull { installed(it) }
        val su = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/system/sbin/su")
            .any { File(it).exists() }
        return mapOf(
            "manufacturer" to Build.MANUFACTURER,
            "brand" to Build.BRAND,
            "model" to Build.MODEL,
            "sdk" to Build.VERSION.SDK_INT,
            "release" to Build.VERSION.RELEASE,
            "display" to Build.DISPLAY,
            "themePkg" to pkg,
            "root" to su
        )
    }

    private fun openThemeStore(): Boolean {
        for (p in themePkgs) {
            val i = packageManager.getLaunchIntentForPackage(p)
            if (i != null) { startActivity(i); return true }
        }
        return false
    }

    private fun saveToDownloads(path: String, name: String): String? {
        return try {
            val src = File(path)
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
                contentResolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
                "Download/$name"
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                src.copyTo(File(dir, name), true)
                "Download/$name"
            }
        } catch (e: Exception) { null }
    }
}
