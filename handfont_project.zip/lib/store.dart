import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

/// Characters in drawing order. 12 per page (3 columns x 4 rows).
const String kChars =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,!?-:;()@&\'"/+=*%#_';
const int kPerPage = 12;
int get kPageCount => (kChars.length / kPerPage).ceil();

String pageLabel(int page) {
  final start = page * kPerPage;
  final end = (start + kPerPage > kChars.length ? kChars.length : start + kPerPage) - 1;
  return '${kChars[start]}  –  ${kChars[end]}';
}

/// One pen stroke. Points are normalised to the cell: x,y in 0..1.
class Stroke {
  final List<Offset> pts;
  Stroke(this.pts);
  Stroke copy() => Stroke(List<Offset>.of(pts));
}

class _Snap {
  final String ch;
  final List<Stroke> strokes;
  _Snap(this.ch, this.strokes);
}

class GlyphStore extends ChangeNotifier {
  final File _file;
  final Map<String, List<Stroke>> glyphs = {};

  /// Pen thickness in font units (em = 1000).
  double thickness = 70;
  String fontName = 'MyHandwriting';

  final List<_Snap> _undo = [];
  final List<_Snap> _redo = [];
  Timer? _timer;

  GlyphStore._(this._file);

  static Future<GlyphStore> load() async {
    final dir = await getApplicationDocumentsDirectory();
    final s = GlyphStore._(File('${dir.path}/glyphs.json'));
    try {
      if (await s._file.exists()) {
        final j = jsonDecode(await s._file.readAsString()) as Map<String, dynamic>;
        s.thickness = (j['thickness'] as num?)?.toDouble() ?? 70;
        s.fontName = (j['name'] as String?) ?? 'MyHandwriting';
        final g = (j['glyphs'] as Map<String, dynamic>?) ?? {};
        g.forEach((ch, strokes) {
          s.glyphs[ch] = (strokes as List)
              .map((st) => Stroke((st as List)
                  .map((p) => Offset((p[0] as num).toDouble(), (p[1] as num).toDouble()))
                  .toList()))
              .toList();
        });
      }
    } catch (_) {
      // corrupt file: start fresh rather than crash
    }
    return s;
  }

  bool has(String ch) => (glyphs[ch]?.isNotEmpty ?? false);
  int get drawnCount => kChars.split('').where(has).length;
  bool get canUndo => _undo.isNotEmpty;
  bool get canRedo => _redo.isNotEmpty;

  // ---- editing ----
  void beginEdit(String ch) {
    _undo.add(_Snap(ch, (glyphs[ch] ?? []).map((s) => s.copy()).toList()));
    if (_undo.length > 300) _undo.removeAt(0);
    _redo.clear();
  }

  /// Drops the snapshot taken by [beginEdit] when nothing actually changed.
  void cancelEdit() {
    if (_undo.isNotEmpty) _undo.removeLast();
  }

  Stroke startStroke(String ch, Offset p) {
    final s = Stroke([p]);
    (glyphs[ch] ??= []).add(s);
    notifyListeners();
    return s;
  }

  void extend(Stroke s, Offset p) {
    s.pts.add(p);
    notifyListeners();
  }

  /// Removes strokes that pass within [r] (normalised) of [p].
  bool eraseAt(String ch, Offset p, double r) {
    final list = glyphs[ch];
    if (list == null) return false;
    final before = list.length;
    list.removeWhere((s) => s.pts.any((q) => (q - p).distance < r));
    if (list.length != before) {
      notifyListeners();
      return true;
    }
    return false;
  }

  void endEdit() => _scheduleSave();

  void clearChar(String ch) {
    if (!has(ch)) return;
    beginEdit(ch);
    glyphs[ch] = [];
    notifyListeners();
    _scheduleSave();
  }

  void clearPage(int page) {
    for (var i = page * kPerPage; i < (page + 1) * kPerPage && i < kChars.length; i++) {
      clearChar(kChars[i]);
    }
  }

  void undo() {
    if (_undo.isEmpty) return;
    final snap = _undo.removeLast();
    _redo.add(_Snap(snap.ch, (glyphs[snap.ch] ?? []).map((s) => s.copy()).toList()));
    glyphs[snap.ch] = snap.strokes;
    notifyListeners();
    _scheduleSave();
  }

  void redo() {
    if (_redo.isEmpty) return;
    final snap = _redo.removeLast();
    _undo.add(_Snap(snap.ch, (glyphs[snap.ch] ?? []).map((s) => s.copy()).toList()));
    glyphs[snap.ch] = snap.strokes;
    notifyListeners();
    _scheduleSave();
  }

  void setThickness(double v) {
    thickness = v;
    notifyListeners();
    _scheduleSave();
  }

  void setName(String n) {
    fontName = n;
    _scheduleSave();
  }

  // ---- saving ----
  void _scheduleSave() {
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 400), saveNow);
  }

  Future<void> saveNow() async {
    _timer?.cancel();
    double r(double v) => (v * 10000).round() / 10000;
    final out = <String, dynamic>{
      'thickness': thickness,
      'name': fontName,
      'glyphs': {
        for (final e in glyphs.entries)
          if (e.value.isNotEmpty)
            e.key: e.value
                .map((s) => s.pts.map((p) => [r(p.dx), r(p.dy)]).toList())
                .toList(),
      },
    };
    await _file.writeAsString(jsonEncode(out));
  }

  /// Plain-number view for the exporter (keeps the exporter free of Flutter types).
  Map<String, List<List<List<double>>>> exportData() {
    return {
      for (final e in glyphs.entries)
        if (e.value.isNotEmpty)
          e.key: e.value
              .map((s) => s.pts.map((p) => [p.dx, p.dy]).toList())
              .toList(),
    };
  }
}
