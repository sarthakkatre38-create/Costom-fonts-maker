import 'package:flutter/material.dart';

import 'store.dart';
import 'theme.dart';

/// Drawing screen: a 3 x 4 grid, one cell per letter (like the reference layout).
class DrawPage extends StatefulWidget {
  final GlyphStore store;
  const DrawPage({super.key, required this.store});

  @override
  State<DrawPage> createState() => _DrawPageState();
}

class _DrawPageState extends State<DrawPage> {
  int page = 0;
  bool eraser = false;

  // active stroke state
  String? _ch;
  Stroke? _stroke;
  Rect? _cell;
  bool _erased = false;
  int? _pointer; // only the first finger draws (ignores palm / second touch)

  GlyphStore get store => widget.store;

  // grid geometry for the current canvas size
  double _size = 0;
  Offset _origin = Offset.zero;

  void _layout(Size s) {
    _size = (s.width / 3) < (s.height / 4) ? s.width / 3 : s.height / 4;
    _origin = Offset((s.width - 3 * _size) / 2, (s.height - 4 * _size) / 2);
  }

  Rect _cellRect(int col, int row) =>
      Rect.fromLTWH(_origin.dx + col * _size, _origin.dy + row * _size, _size, _size);

  Offset _norm(Offset p) {
    final c = _cell!;
    double unit(double v) => v < 0 ? 0.0 : (v > 1 ? 1.0 : v);
    return Offset(unit((p.dx - c.left) / c.width), unit((p.dy - c.top) / c.height));
  }

  void _down(PointerDownEvent e) {
    if (_pointer != null) return;
    final p = e.localPosition;
    final col = ((p.dx - _origin.dx) / _size).floor();
    final row = ((p.dy - _origin.dy) / _size).floor();
    if (col < 0 || col > 2 || row < 0 || row > 3) return;
    final index = page * kPerPage + row * 3 + col;
    if (index >= kChars.length) return;
    _pointer = e.pointer;
    _ch = kChars[index];
    _cell = _cellRect(col, row);
    _erased = false;
    store.beginEdit(_ch!);
    if (eraser) {
      _erased = store.eraseAt(_ch!, _norm(p), 0.07) || _erased;
    } else {
      _stroke = store.startStroke(_ch!, _norm(p));
    }
  }

  void _move(PointerMoveEvent e) {
    if (e.pointer != _pointer || _ch == null || _cell == null) return;
    final n = _norm(e.localPosition);
    if (eraser) {
      _erased = store.eraseAt(_ch!, n, 0.07) || _erased;
    } else if (_stroke != null) {
      if ((n - _stroke!.pts.last).distance > 0.004) store.extend(_stroke!, n);
    }
  }

  void _up(PointerEvent e) {
    if (e.pointer != _pointer || _ch == null) return;
    if (_stroke != null && _stroke!.pts.length == 1) {
      // a tap becomes a dot
      final p = _stroke!.pts.first;
      store.extend(_stroke!, Offset(p.dx + 0.002, p.dy));
    }
    if (eraser && !_erased) store.cancelEdit();
    store.endEdit();
    _pointer = null;
    _ch = null;
    _stroke = null;
    _cell = null;
  }

  Future<void> _confirmClearPage() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Clear this page?'),
        content: const Text('All letters on this page will be erased. You can undo each one.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('Cancel', style: TextStyle(color: C.ink))),
          TextButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('Clear', style: TextStyle(color: C.pink))),
        ],
      ),
    );
    if (ok == true) store.clearPage(page);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListenableBuilder(
          listenable: store,
          builder: (context, _) {
            return Column(
              children: [
                // top bar
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Row(
                    children: [
                      FlatIcon(icon: Icons.arrow_back, onTap: () => Navigator.pop(context)),
                      const Spacer(),
                      FlatIcon(icon: Icons.undo, onTap: store.canUndo ? store.undo : null),
                      FlatIcon(icon: Icons.redo, onTap: store.canRedo ? store.redo : null),
                      FlatIcon(icon: Icons.delete_outline, onTap: _confirmClearPage),
                    ],
                  ),
                ),
                // canvas
                Expanded(
                  child: LayoutBuilder(builder: (context, box) {
                    _layout(Size(box.maxWidth, box.maxHeight));
                    return Listener(
                      behavior: HitTestBehavior.opaque,
                      onPointerDown: _down,
                      onPointerMove: _move,
                      onPointerUp: _up,
                      onPointerCancel: _up,
                      child: CustomPaint(
                        size: Size(box.maxWidth, box.maxHeight),
                        painter: _GridPainter(store, page, _size, _origin),
                      ),
                    );
                  }),
                ),
                // tools
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          FlatIcon(icon: Icons.edit, active: !eraser, onTap: () => setState(() => eraser = false)),
                          const SizedBox(width: 4),
                          FlatIcon(
                              icon: Icons.cleaning_services_outlined,
                              active: eraser,
                              activeColor: C.teal,
                              onTap: () => setState(() => eraser = true)),
                          const SizedBox(width: 8),
                          const Text('Thin', style: TextStyle(fontSize: 12, color: C.muted)),
                          Expanded(
                            child: Slider(
                              value: store.thickness,
                              min: 35,
                              max: 140,
                              onChanged: store.setThickness,
                            ),
                          ),
                          const Text('Bold', style: TextStyle(fontSize: 12, color: C.muted)),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          FlatIcon(
                              icon: Icons.chevron_left,
                              onTap: page > 0 ? () => setState(() => page--) : null),
                          Text(
                            '${pageLabel(page)}     ${page + 1}/$kPageCount',
                            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                          ),
                          FlatIcon(
                              icon: Icons.chevron_right,
                              onTap: page < kPageCount - 1 ? () => setState(() => page++) : null),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  final GlyphStore store;
  final int page;
  final double s;
  final Offset o;
  _GridPainter(this.store, this.page, this.s, this.o) : super(repaint: store);

  @override
  void paint(Canvas canvas, Size size) {
    final guide = Paint()
      ..color = C.line
      ..strokeWidth = 1.2;
    final grid = Paint()
      ..color = C.ink
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    final ink = Paint()
      ..color = C.ink
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = store.thickness / 1000 * s;

    for (var row = 0; row < 4; row++) {
      for (var col = 0; col < 3; col++) {
        final index = page * kPerPage + row * 3 + col;
        final r = Rect.fromLTWH(o.dx + col * s, o.dy + row * s, s, s);
        if (index >= kChars.length) {
          canvas.drawRect(r, Paint()..color = C.line.withValues(alpha: 0.35));
          continue;
        }
        final ch = kChars[index];
        // baseline + x-height + cap-height guides
        final base = r.top + r.height * 0.78;
        canvas.drawLine(Offset(r.left, base), Offset(r.right, base),
            guide..strokeWidth = 1.8);
        canvas.drawLine(Offset(r.left, r.top + r.height * 0.45),
            Offset(r.right, r.top + r.height * 0.45), guide..strokeWidth = 1.0);
        canvas.drawLine(Offset(r.left, r.top + r.height * 0.12),
            Offset(r.right, r.top + r.height * 0.12), guide..strokeWidth = 1.0);

        // small label in the corner
        final tp = TextPainter(
          text: TextSpan(
            text: ch,
            style: TextStyle(
              color: store.has(ch) ? C.teal : C.pink,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
          textDirection: TextDirection.ltr,
        )..layout();
        tp.paint(canvas, Offset(r.left + 6, r.bottom - tp.height - 4));

        // strokes, clipped to the cell
        canvas.save();
        canvas.clipRect(r);
        for (final st in store.glyphs[ch] ?? const <Stroke>[]) {
          if (st.pts.length == 1) {
            canvas.drawCircle(
                Offset(r.left + st.pts[0].dx * s, r.top + st.pts[0].dy * s),
                ink.strokeWidth / 2,
                Paint()..color = C.ink);
            continue;
          }
          final path = Path()
            ..moveTo(r.left + st.pts[0].dx * s, r.top + st.pts[0].dy * s);
          for (final p in st.pts.skip(1)) {
            path.lineTo(r.left + p.dx * s, r.top + p.dy * s);
          }
          canvas.drawPath(path, ink);
        }
        canvas.restore();
      }
    }

    // grid lines
    for (var i = 0; i <= 3; i++) {
      canvas.drawLine(Offset(o.dx + i * s, o.dy), Offset(o.dx + i * s, o.dy + 4 * s), grid);
    }
    for (var j = 0; j <= 4; j++) {
      canvas.drawLine(Offset(o.dx, o.dy + j * s), Offset(o.dx + 3 * s, o.dy + j * s), grid);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) =>
      old.page != page || old.s != s || old.o != o;
}
