// Builds a real TrueType (.ttf) font from hand-drawn strokes.
// Pure Dart (no Flutter imports) so it can be unit tested.
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

const int kUpm = 1000;
const double kBaseline = 0.78; // baseline sits 78% down the drawing cell
const int kAscent = 800;
const int kDescent = -220;
const int kSideBearing = 60;
const int kSpaceAdvance = 300;

class _W {
  final BytesBuilder b = BytesBuilder();
  void u8(int v) => b.addByte(v & 0xFF);
  void u16(int v) {
    b.addByte((v >> 8) & 0xFF);
    b.addByte(v & 0xFF);
  }

  void i16(int v) => u16(v & 0xFFFF);
  void u32(int v) {
    u16((v >> 16) & 0xFFFF);
    u16(v & 0xFFFF);
  }

  void i64(int v) {
    u32((v >> 32) & 0xFFFFFFFF);
    u32(v & 0xFFFFFFFF);
  }

  void bytes(List<int> x) => b.add(x);
  int get length => b.length;
  Uint8List toBytes() => b.toBytes();
}

class _Glyph {
  Uint8List data = Uint8List(0);
  int advance = kSpaceAdvance;
  int xMin = 0, yMin = 0, xMax = 0, yMax = 0;
  int contours = 0, points = 0;
  bool get isEmpty => data.isEmpty;
}

List<List<int>> _circle(double cx, double cy, double r) {
  const n = 12;
  return [
    for (var i = 0; i < n; i++)
      [
        (cx + r * math.cos(2 * math.pi * i / n)).round(),
        (cy + r * math.sin(2 * math.pi * i / n)).round(),
      ]
  ];
}

double _area(List<List<int>> poly) {
  var a = 0.0;
  for (var i = 0; i < poly.length; i++) {
    final p = poly[i], q = poly[(i + 1) % poly.length];
    a += p[0] * q[1] - q[0] * p[1];
  }
  return a / 2;
}

/// Turns pen strokes (normalised cell coords) into overlapping filled contours.
List<List<List<int>>> _outline(
    List<List<List<double>>> strokes, double thickness, double spacing) {
  final r = thickness / 2;
  final polys = <List<List<int>>>[];
  for (final stroke in strokes) {
    if (stroke.isEmpty) continue;
    // to font units, y up
    var pts = [
      for (final p in stroke) [p[0] * kUpm, (kBaseline - p[1]) * kUpm]
    ];
    // resample so points are at least ~14 units apart
    final rs = <List<double>>[pts.first];
    for (final p in pts.skip(1)) {
      final d = math.sqrt(math.pow(p[0] - rs.last[0], 2) + math.pow(p[1] - rs.last[1], 2));
      if (d >= spacing) rs.add(p);
    }
    if (pts.length > 1 && (pts.last[0] != rs.last[0] || pts.last[1] != rs.last[1])) {
      rs.add(pts.last);
    }
    // light smoothing (one pass, ends stay put)
    final sm = <List<double>>[
      for (var i = 0; i < rs.length; i++)
        (i == 0 || i == rs.length - 1)
            ? rs[i]
            : [
                (rs[i - 1][0] + 2 * rs[i][0] + rs[i + 1][0]) / 4,
                (rs[i - 1][1] + 2 * rs[i][1] + rs[i + 1][1]) / 4,
              ]
    ];
    for (final p in sm) {
      polys.add(_circle(p[0], p[1], r));
    }
    for (var i = 0; i + 1 < sm.length; i++) {
      final a = sm[i], b = sm[i + 1];
      final dx = b[0] - a[0], dy = b[1] - a[1];
      final len = math.sqrt(dx * dx + dy * dy);
      if (len < 0.001) continue;
      final nx = -dy / len * r, ny = dx / len * r;
      polys.add([
        [(a[0] + nx).round(), (a[1] + ny).round()],
        [(b[0] + nx).round(), (b[1] + ny).round()],
        [(b[0] - nx).round(), (b[1] - ny).round()],
        [(a[0] - nx).round(), (a[1] - ny).round()],
      ]);
    }
  }
  // Same winding direction (clockwise) for every contour so overlaps merge
  // under the non-zero fill rule instead of cutting holes.
  return [
    for (final p in polys) (_area(p) > 0 ? p.reversed.toList() : p)
  ];
}

_Glyph _buildGlyph(List<List<List<double>>> strokes, double thickness) {
  final g = _Glyph();
  // Heavy scribbles can produce too many points for one glyph (limit 65535),
  // so keep widening the point spacing until it fits comfortably.
  var spacing = 14.0;
  var contours = _outline(strokes, thickness, spacing);
  for (var tries = 0; tries < 8; tries++) {
    var count = 0;
    for (final c in contours) {
      count += c.length;
    }
    if (count <= 30000) break;
    spacing *= 1.8;
    contours = _outline(strokes, thickness, spacing);
  }
  if (contours.isEmpty) return g;

  var xMin = 1 << 30, yMin = 1 << 30, xMax = -(1 << 30), yMax = -(1 << 30);
  for (final c in contours) {
    for (final p in c) {
      xMin = math.min(xMin, p[0]);
      xMax = math.max(xMax, p[0]);
      yMin = math.min(yMin, p[1]);
      yMax = math.max(yMax, p[1]);
    }
  }
  // left side bearing is always kSideBearing
  final shift = kSideBearing - xMin;
  contours = [
    for (final c in contours) [for (final p in c) [p[0] + shift, p[1]]]
  ];
  xMax += shift;
  xMin = kSideBearing;

  final w = _W();
  w.i16(contours.length);
  w.i16(xMin);
  w.i16(yMin);
  w.i16(xMax);
  w.i16(yMax);
  var end = -1;
  for (final c in contours) {
    end += c.length;
    w.u16(end);
  }
  w.u16(0); // no instructions
  final total = end + 1;
  // flags: on-curve, int16 deltas; OVERLAP_SIMPLE (0x40) on first point
  for (var i = 0; i < total; i++) {
    w.u8(i == 0 ? 0x41 : 0x01);
  }
  var px = 0;
  for (final c in contours) {
    for (final p in c) {
      w.i16(p[0] - px);
      px = p[0];
    }
  }
  var py = 0;
  for (final c in contours) {
    for (final p in c) {
      w.i16(p[1] - py);
      py = p[1];
    }
  }
  while (w.length % 4 != 0) {
    w.u8(0);
  }
  g.data = w.toBytes();
  g.xMin = xMin;
  g.yMin = yMin;
  g.xMax = xMax;
  g.yMax = yMax;
  g.contours = contours.length;
  g.points = total;
  g.advance = math.max(250, (xMax - xMin) + 2 * kSideBearing);
  return g;
}

int _checksum(List<int> d) {
  var sum = 0;
  for (var i = 0; i < d.length; i += 4) {
    final v = (d[i] << 24) |
        ((i + 1 < d.length ? d[i + 1] : 0) << 16) |
        ((i + 2 < d.length ? d[i + 2] : 0) << 8) |
        (i + 3 < d.length ? d[i + 3] : 0);
    sum = (sum + v) & 0xFFFFFFFF;
  }
  return sum;
}

Uint8List _utf16be(String s) {
  final w = _W();
  for (final u in s.codeUnits) {
    w.u16(u);
  }
  return w.toBytes();
}

/// [glyphs]: char -> strokes -> points [x, y] (cell-normalised 0..1).
Uint8List buildTtf({
  required String family,
  required Map<String, List<List<List<double>>>> glyphs,
  double thickness = 70,
}) {
  final psName = family.replaceAll(RegExp(r'[^A-Za-z0-9]'), '');
  final safeFamily = family.trim().isEmpty ? 'MyHandwriting' : family.trim();
  final ps = psName.isEmpty ? 'MyHandwriting' : psName;

  // glyph order: .notdef, space, then drawn chars sorted by code point
  final chars = glyphs.keys.where((k) => k.isNotEmpty && k.codeUnitAt(0) != 32).toList()
    ..sort((a, b) => a.codeUnitAt(0).compareTo(b.codeUnitAt(0)));
  final built = <_Glyph>[_Glyph(), _Glyph()..advance = kSpaceAdvance];
  final cps = <int>[32];
  for (final ch in chars) {
    final g = _buildGlyph(glyphs[ch]!, thickness);
    if (g.isEmpty) continue;
    built.add(g);
    cps.add(ch.codeUnitAt(0));
  }
  final n = built.length;

  // ---- glyf + loca ----
  final glyf = _W();
  final loca = _W();
  var maxPoints = 0, maxContours = 0;
  var gx0 = 1 << 30, gy0 = 1 << 30, gx1 = -(1 << 30), gy1 = -(1 << 30);
  var advMax = 0, minLsb = 1 << 30, minRsb = 1 << 30, xMaxExt = 0, advSum = 0;
  for (final g in built) {
    loca.u32(glyf.length);
    glyf.bytes(g.data);
    maxPoints = math.max(maxPoints, g.points);
    maxContours = math.max(maxContours, g.contours);
    advMax = math.max(advMax, g.advance);
    advSum += g.advance;
    if (!g.isEmpty) {
      gx0 = math.min(gx0, g.xMin);
      gy0 = math.min(gy0, g.yMin);
      gx1 = math.max(gx1, g.xMax);
      gy1 = math.max(gy1, g.yMax);
      minLsb = math.min(minLsb, g.xMin);
      minRsb = math.min(minRsb, g.advance - g.xMax);
      xMaxExt = math.max(xMaxExt, g.xMax);
    }
  }
  loca.u32(glyf.length);
  if (gx0 == 1 << 30) {
    gx0 = gy0 = gx1 = gy1 = 0;
    minLsb = minRsb = 0;
  }

  // ---- hmtx ----
  final hmtx = _W();
  for (final g in built) {
    hmtx.u16(g.advance);
    hmtx.i16(g.isEmpty ? 0 : g.xMin);
  }

  // ---- head ----
  final head = _W();
  head.u32(0x00010000);
  head.u32(0x00010000);
  head.u32(0); // checkSumAdjustment (patched later)
  head.u32(0x5F0F3CF5);
  head.u16(0x000B);
  head.u16(kUpm);
  final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000 + 2082844800;
  head.i64(now);
  head.i64(now);
  head.i16(gx0);
  head.i16(gy0);
  head.i16(gx1);
  head.i16(gy1);
  head.u16(0); // macStyle
  head.u16(8); // lowestRecPPEM
  head.i16(2); // fontDirectionHint
  head.i16(1); // long loca
  head.i16(0); // glyphDataFormat

  // ---- hhea ----
  final hhea = _W();
  hhea.u32(0x00010000);
  hhea.i16(kAscent);
  hhea.i16(kDescent);
  hhea.i16(0);
  hhea.u16(advMax);
  hhea.i16(minLsb);
  hhea.i16(minRsb);
  hhea.i16(xMaxExt);
  hhea.i16(1); // caretSlopeRise
  hhea.i16(0);
  hhea.i16(0);
  for (var i = 0; i < 4; i++) {
    hhea.i16(0);
  }
  hhea.i16(0);
  hhea.u16(n);

  // ---- maxp ----
  final maxp = _W();
  maxp.u32(0x00010000);
  maxp.u16(n);
  maxp.u16(maxPoints);
  maxp.u16(maxContours);
  maxp.u16(0);
  maxp.u16(0);
  maxp.u16(2);
  for (var i = 0; i < 8; i++) {
    maxp.u16(0);
  }

  // ---- OS/2 (v4) ----
  final os2 = _W();
  os2.u16(4);
  os2.i16(n > 0 ? advSum ~/ n : 500);
  os2.u16(400);
  os2.u16(5);
  os2.u16(0);
  os2.i16(650);
  os2.i16(600);
  os2.i16(0);
  os2.i16(75);
  os2.i16(650);
  os2.i16(600);
  os2.i16(0);
  os2.i16(350);
  os2.i16(50);
  os2.i16(300);
  os2.i16(0);
  os2.bytes(List<int>.filled(10, 0));
  os2.u32(1);
  os2.u32(0);
  os2.u32(0);
  os2.u32(0);
  os2.bytes(ascii.encode('HFNT'));
  os2.u16(0x40);
  os2.u16(cps.reduce(math.min));
  os2.u16(cps.reduce(math.max));
  os2.i16(kAscent);
  os2.i16(kDescent);
  os2.i16(0);
  os2.u16(1000);
  os2.u16(300);
  os2.u32(1);
  os2.u32(0);
  os2.i16(450);
  os2.i16(700);
  os2.u16(0);
  os2.u16(32);
  os2.u16(1);

  // ---- cmap (format 4, one segment per character) ----
  final sorted = List<int>.of(cps)..sort();
  final segCount = sorted.length + 1;
  var pow2 = 1, log2 = 0;
  while (pow2 * 2 <= segCount) {
    pow2 *= 2;
    log2++;
  }
  final searchRange = 2 * pow2;
  final sub = _W();
  sub.u16(4);
  sub.u16(16 + 8 * segCount);
  sub.u16(0);
  sub.u16(segCount * 2);
  sub.u16(searchRange);
  sub.u16(log2);
  sub.u16(segCount * 2 - searchRange);
  for (final c in sorted) {
    sub.u16(c);
  }
  sub.u16(0xFFFF);
  sub.u16(0);
  for (final c in sorted) {
    sub.u16(c);
  }
  sub.u16(0xFFFF);
  for (final c in sorted) {
    sub.u16((cps.indexOf(c) + 1 - c) & 0xFFFF);
  }
  sub.u16(1);
  for (var i = 0; i < segCount; i++) {
    sub.u16(0);
  }
  final cmap = _W();
  cmap.u16(0);
  cmap.u16(2);
  cmap.u16(0); // Unicode platform
  cmap.u16(3);
  cmap.u32(20);
  cmap.u16(3); // Windows platform
  cmap.u16(1);
  cmap.u32(20);
  cmap.bytes(sub.toBytes());

  // ---- name ----
  final names = <List<dynamic>>[
    [1, safeFamily],
    [2, 'Regular'],
    [3, '$ps-Regular-Handfont'],
    [4, safeFamily],
    [5, 'Version 1.0'],
    [6, '$ps-Regular'],
  ];
  final strings = _W();
  final recs = _W();
  for (final nm in names) {
    final s = _utf16be(nm[1] as String);
    recs.u16(3);
    recs.u16(1);
    recs.u16(0x409);
    recs.u16(nm[0] as int);
    recs.u16(s.length);
    recs.u16(strings.length);
    strings.bytes(s);
  }
  final name = _W();
  name.u16(0);
  name.u16(names.length);
  name.u16(6 + 12 * names.length);
  name.bytes(recs.toBytes());
  name.bytes(strings.toBytes());

  // ---- post (v3, no glyph names) ----
  final post = _W();
  post.u32(0x00030000);
  post.u32(0);
  post.i16(-100);
  post.i16(50);
  for (var i = 0; i < 5; i++) {
    post.u32(0);
  }

  // ---- assemble ----
  final tables = <String, Uint8List>{
    'OS/2': os2.toBytes(),
    'cmap': cmap.toBytes(),
    'glyf': glyf.toBytes(),
    'head': head.toBytes(),
    'hhea': hhea.toBytes(),
    'hmtx': hmtx.toBytes(),
    'loca': loca.toBytes(),
    'maxp': maxp.toBytes(),
    'name': name.toBytes(),
    'post': post.toBytes(),
  };
  final tags = tables.keys.toList()..sort();
  final numTables = tags.length;
  var p2 = 1, l2 = 0;
  while (p2 * 2 <= numTables) {
    p2 *= 2;
    l2++;
  }
  final out = _W();
  out.u32(0x00010000);
  out.u16(numTables);
  out.u16(p2 * 16);
  out.u16(l2);
  out.u16(numTables * 16 - p2 * 16);
  var offset = 12 + 16 * numTables;
  final offsets = <String, int>{};
  for (final t in tags) {
    final d = tables[t]!;
    offsets[t] = offset;
    out.bytes(ascii.encode(t));
    out.u32(_checksum(d));
    out.u32(offset);
    out.u32(d.length);
    offset += (d.length + 3) & ~3;
  }
  for (final t in tags) {
    final d = tables[t]!;
    out.bytes(d);
    for (var i = d.length; i % 4 != 0; i++) {
      out.u8(0);
    }
  }
  final file = out.toBytes();
  final adj = (0xB1B0AFBA - _checksum(file)) & 0xFFFFFFFF;
  final hp = offsets['head']! + 8;
  file[hp] = (adj >> 24) & 0xFF;
  file[hp + 1] = (adj >> 16) & 0xFF;
  file[hp + 2] = (adj >> 8) & 0xFF;
  file[hp + 3] = adj & 0xFF;
  return file;
}
