import 'package:flutter/material.dart';

import 'store.dart';
import 'theme.dart';

/// Type any text and see it written in your own letters.
class PreviewPage extends StatefulWidget {
  final GlyphStore store;
  const PreviewPage({super.key, required this.store});

  @override
  State<PreviewPage> createState() => _PreviewPageState();
}

class _PreviewPageState extends State<PreviewPage> {
  final _c = TextEditingController(text: 'Hello World 123');

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                FlatIcon(icon: Icons.arrow_back, onTap: () => Navigator.pop(context)),
                const SizedBox(width: 8),
                const Text('Preview', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              ]),
              const SizedBox(height: 12),
              TextField(
                controller: _c,
                maxLines: 3,
                minLines: 1,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  filled: true,
                  fillColor: C.card,
                  border: OutlineInputBorder(
                      borderSide: BorderSide(color: C.line), borderRadius: BorderRadius.all(Radius.circular(6))),
                  enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: C.line), borderRadius: BorderRadius.all(Radius.circular(6))),
                  focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: C.ink, width: 2),
                      borderRadius: BorderRadius.all(Radius.circular(6))),
                  hintText: 'Type something',
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(6)),
                  child: LayoutBuilder(
                    builder: (context, box) => CustomPaint(
                      painter: _TextPainter(widget.store, _c.text, 44),
                      size: Size(box.maxWidth, box.maxHeight),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text('Letters you have not drawn yet show as gaps.',
                  style: TextStyle(color: C.muted, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

class _TextPainter extends CustomPainter {
  final GlyphStore store;
  final String text;
  final double fontSize;
  _TextPainter(this.store, this.text, this.fontSize);

  @override
  void paint(Canvas canvas, Size size) {
    final k = fontSize / 1000;
    final thick = store.thickness;
    final paint = Paint()
      ..color = C.ink
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = thick * k;
    const pad = 16.0;
    var x = pad, baseY = pad + fontSize * 0.8;
    for (final ch in text.split('')) {
      if (ch == '\n') {
        x = pad;
        baseY += fontSize * 1.3;
        continue;
      }
      final strokes = store.glyphs[ch];
      double adv;
      double? xmin;
      if (ch == ' ' || strokes == null || strokes.isEmpty) {
        adv = ch == ' ' ? 300 : 500;
      } else {
        var lo = 1.0, hi = 0.0;
        for (final s in strokes) {
          for (final p in s.pts) {
            if (p.dx < lo) lo = p.dx;
            if (p.dx > hi) hi = p.dx;
          }
        }
        xmin = lo;
        adv = ((hi - lo) * 1000 + thick + 120).clamp(250, 2000).toDouble();
      }
      if (x + adv * k > size.width - pad && x > pad) {
        x = pad;
        baseY += fontSize * 1.3;
      }
      if (xmin != null) {
        for (final s in strokes!) {
          Offset map(Offset p) => Offset(
                x + ((p.dx - xmin!) * 1000 + thick / 2 + 60) * k,
                baseY - (0.78 - p.dy) * 1000 * k,
              );
          if (s.pts.length == 1) {
            canvas.drawCircle(map(s.pts[0]), thick * k / 2, Paint()..color = C.ink);
            continue;
          }
          final path = Path()..moveTo(map(s.pts[0]).dx, map(s.pts[0]).dy);
          for (final p in s.pts.skip(1)) {
            final m = map(p);
            path.lineTo(m.dx, m.dy);
          }
          canvas.drawPath(path, paint);
        }
      }
      x += adv * k;
    }
  }

  @override
  bool shouldRepaint(covariant _TextPainter old) => true;
}
