import 'package:flutter/services.dart';

const _ch = MethodChannel('handfont/device');

enum CompatLevel { likely, exportOnly }

class Compat {
  final CompatLevel level;
  final String headline;
  final List<String> details;
  final String? themePkg;
  const Compat(this.level, this.headline, this.details, this.themePkg);

  bool get hasThemeStore => themePkg != null;
}

/// Runs every time the app opens (so also right after install).
/// Reads only local device info - no network involved.
Future<Compat> checkCompat() async {
  try {
    final m = await _ch.invokeMapMethod<String, dynamic>('info');
    if (m == null) throw Exception('no info');
    final brand = ((m['brand'] ?? '') as String).toLowerCase();
    final maker = ((m['manufacturer'] ?? '') as String).toLowerCase();
    final model = (m['model'] ?? '') as String;
    final sdk = (m['sdk'] ?? 0) as int;
    final release = (m['release'] ?? '') as String;
    final display = (m['display'] ?? '') as String;
    final themePkg = m['themePkg'] as String?;
    final root = (m['root'] ?? false) as bool;

    final details = <String>[
      'Phone: ${brand.isEmpty ? maker : brand} $model',
      'Android $release (API $sdk)',
      if (display.isNotEmpty) 'Build: $display',
      'Theme / font store: ${themePkg != null ? 'found' : 'not found'}',
      if (root) 'Root access: detected',
    ];

    final oppoFamily = ['realme', 'oppo', 'oneplus'].any((b) => brand.contains(b) || maker.contains(b));
    if (oppoFamily && themePkg != null) {
      return Compat(
        CompatLevel.likely,
        'Likely compatible',
        [
          ...details,
          'Export your font, then apply it from the phone\'s Theme Store / font settings.',
          'Newer system versions can block third-party fonts, so this is a best guess.',
        ],
        themePkg,
      );
    }
    return Compat(
      CompatLevel.exportOnly,
      'Export only',
      [
        ...details,
        'This phone has no known way for an app to set a system font.',
        'Your .ttf still works in Canva, WPS, Word and other apps that accept custom fonts.',
      ],
      themePkg,
    );
  } catch (_) {
    return const Compat(
      CompatLevel.exportOnly,
      'Could not check this phone',
      ['Exporting the .ttf still works.'],
      null,
    );
  }
}

Future<bool> openThemeStore() async {
  try {
    return (await _ch.invokeMethod<bool>('openThemeStore')) ?? false;
  } catch (_) {
    return false;
  }
}

/// Copies the file into the phone's Downloads folder. Returns a display path or null.
Future<String?> saveToDownloads(String path, String name) async {
  try {
    return await _ch.invokeMethod<String>('saveToDownloads', {'path': path, 'name': name});
  } catch (_) {
    return null;
  }
}
