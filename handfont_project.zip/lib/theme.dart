import 'package:flutter/material.dart';

/// Flat palette taken from the logo (pink + teal on warm paper).
/// No gradients, no glass, no highlight/ripple effects anywhere.
class C {
  static const paper = Color(0xFFF6F1EA);
  static const ink = Color(0xFF1C1C21);
  static const pink = Color(0xFFF95FA4);
  static const teal = Color(0xFF5CC6D3);
  static const line = Color(0xFFD9D0C2);
  static const card = Color(0xFFFFFFFF);
  static const muted = Color(0xFF6B675F);
}

ThemeData buildTheme() {
  return ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: C.paper,
    colorScheme: const ColorScheme.light(
      primary: C.ink,
      secondary: C.pink,
      surface: C.paper,
      onPrimary: Colors.white,
    ),
    splashFactory: NoSplash.splashFactory,
    splashColor: Colors.transparent,
    highlightColor: Colors.transparent,
    hoverColor: Colors.transparent,
    focusColor: Colors.transparent,
    textTheme: const TextTheme().apply(bodyColor: C.ink, displayColor: C.ink),
    sliderTheme: const SliderThemeData(
      trackHeight: 4,
      activeTrackColor: C.ink,
      inactiveTrackColor: C.line,
      thumbColor: C.ink,
      overlayColor: Colors.transparent,
      overlayShape: RoundSliderOverlayShape(overlayRadius: 0),
      trackShape: RectangularSliderTrackShape(),
    ),
    dialogTheme: const DialogThemeData(
      backgroundColor: C.card,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
    ),
  );
}

/// Flat solid button: no elevation, no ripple, no pressed highlight.
class FlatBtn extends StatelessWidget {
  final String label;
  final IconData? icon;
  final Color color;
  final Color textColor;
  final VoidCallback? onTap;
  final bool outlined;
  final EdgeInsets padding;

  const FlatBtn({
    super.key,
    required this.label,
    required this.onTap,
    this.icon,
    this.color = C.ink,
    this.textColor = Colors.white,
    this.outlined = false,
    this.padding = const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Opacity(
        opacity: enabled ? 1 : 0.4,
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: outlined ? Colors.transparent : color,
            border: outlined ? Border.all(color: C.ink, width: 2) : null,
            borderRadius: BorderRadius.circular(6),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 20, color: outlined ? C.ink : textColor),
                const SizedBox(width: 8),
              ],
              Text(
                label,
                style: TextStyle(
                  color: outlined ? C.ink : textColor,
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Flat icon button (no ripple).
class FlatIcon extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final bool active;
  final Color activeColor;
  const FlatIcon({
    super.key,
    required this.icon,
    required this.onTap,
    this.active = false,
    this.activeColor = C.pink,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Opacity(
        opacity: onTap == null ? 0.3 : 1,
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: active ? activeColor : Colors.transparent,
            borderRadius: BorderRadius.circular(6),
          ),
          child: Icon(icon, size: 24, color: active ? Colors.white : C.ink),
        ),
      ),
    );
  }
}
