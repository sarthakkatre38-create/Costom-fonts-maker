import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'compat.dart';
import 'draw_page.dart';
import 'preview_page.dart';
import 'store.dart';
import 'theme.dart';
import 'ttf.dart';

class HomePage extends StatefulWidget {
  final GlyphStore store;
  const HomePage({super.key, required this.store});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Compat? compat;
  bool showDetails = false;

  GlyphStore get store => widget.store;

  @override
  void initState() {
    super.initState();
    _runCheck(); // every launch (and therefore right after install)
  }

  Future<void> _runCheck() async {
    final c = await checkCompat();
    if (mounted) setState(() => compat = c);
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: C.ink,
      behavior: SnackBarBehavior.floating,
      elevation: 0,
    ));
  }

  Future<void> _export() async {
    if (store.drawnCount == 0) {
      _toast('Draw at least one letter first.');
      return;
    }
    final controller = TextEditingController(text: store.fontName);
    final name = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Name your font'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: C.ink, width: 2)),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c),
              child: const Text('Cancel', style: TextStyle(color: C.ink))),
          TextButton(
              onPressed: () => Navigator.pop(c, controller.text.trim()),
              child: const Text('Export', style: TextStyle(color: C.pink))),
        ],
      ),
    );
    if (name == null || name.isEmpty) return;
    store.setName(name);

    final bytes = buildTtf(family: name, glyphs: store.exportData(), thickness: store.thickness);
    final dir = await getApplicationDocumentsDirectory();
    final fileName = '${name.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_')}.ttf';
    final file = File('${dir.path}/$fileName');
    await file.writeAsBytes(bytes, flush: true);
    final saved = await saveToDownloads(file.path, fileName);
    if (!mounted) return;
    _showExported(file, fileName, saved);
  }

  void _showExported(File file, String fileName, String? savedPath) {
    final missing = kChars.length - store.drawnCount;
    showModalBottomSheet(
      context: context,
      backgroundColor: C.card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(12))),
      builder: (c) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Font exported', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(savedPath != null ? 'Saved to $savedPath' : 'Created $fileName'),
            if (missing > 0) ...[
              const SizedBox(height: 6),
              Text('$missing characters are not drawn yet; those will use the normal phone font.',
                  style: const TextStyle(color: C.muted)),
            ],
            const SizedBox(height: 16),
            Row(children: [
              Expanded(
                child: FlatBtn(
                  label: 'Share file',
                  icon: Icons.ios_share,
                  color: C.pink,
                  onTap: () => Share.shareXFiles([XFile(file.path, mimeType: 'font/ttf')]),
                ),
              ),
              if (compat?.hasThemeStore ?? false) ...[
                const SizedBox(width: 10),
                Expanded(
                  child: FlatBtn(
                    label: 'Theme Store',
                    icon: Icons.palette_outlined,
                    color: C.teal,
                    textColor: C.ink,
                    onTap: () async {
                      final ok = await openThemeStore();
                      if (!ok && mounted) _toast('Could not open the Theme Store.');
                    },
                  ),
                ),
              ],
            ]),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListenableBuilder(
          listenable: store,
          builder: (context, _) => ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Row(children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.asset('assets/logo_512.png', width: 64, height: 64),
                ),
                const SizedBox(width: 14),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Handfont', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
                      Text('Draw your letters. Make them your font.',
                          style: TextStyle(color: C.muted, fontSize: 13)),
                    ],
                  ),
                ),
              ]),
              const SizedBox(height: 24),
              _compatCard(),
              const SizedBox(height: 14),
              _progressCard(),
              const SizedBox(height: 22),
              FlatBtn(
                label: 'Draw letters',
                icon: Icons.edit,
                color: C.pink,
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => DrawPage(store: store))),
              ),
              const SizedBox(height: 10),
              FlatBtn(
                label: 'Preview text',
                icon: Icons.text_fields,
                color: C.teal,
                textColor: C.ink,
                onTap: () => Navigator.push(
                    context, MaterialPageRoute(builder: (_) => PreviewPage(store: store))),
              ),
              const SizedBox(height: 10),
              FlatBtn(label: 'Export font (.ttf)', icon: Icons.file_download_outlined, onTap: _export),
              const SizedBox(height: 22),
              const Text(
                'Works fully offline. No account, no internet permission. Your drawings never leave this phone.',
                style: TextStyle(color: C.muted, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _compatCard() {
    final c = compat;
    final good = c?.level == CompatLevel.likely;
    final color = c == null ? C.line : (good ? C.teal : C.pink);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => setState(() => showDetails = !showDetails),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: C.card,
          border: Border(left: BorderSide(color: color, width: 6)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(
                child: Text(
                  c == null ? 'Checking your phone…' : c.headline,
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                ),
              ),
              Icon(showDetails ? Icons.expand_less : Icons.expand_more, color: C.muted),
            ]),
            if (c != null && showDetails) ...[
              const SizedBox(height: 8),
              for (final d in c.details)
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(d, style: const TextStyle(color: C.muted, fontSize: 13)),
                ),
            ],
          ],
        ),
      ),
      ),
    );
  }

  Widget _progressCard() {
    final done = store.drawnCount;
    final total = kChars.length;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(8)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$done of $total characters drawn',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(3),
            child: SizedBox(
              height: 8,
              child: Stack(children: [
                Container(color: C.line),
                FractionallySizedBox(widthFactor: done / total, child: Container(color: C.pink)),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
